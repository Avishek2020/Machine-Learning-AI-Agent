package de.upb.isml;

import de.upb.isml.thegamef2f.engine.board.Game;
import de.upb.isml.thegamef2f.engine.player.Player;
import de.upb.isml.thegamef2f.engine.player.RandomPlayer;
public class Gameplay {
   
 public static void main(String[] args) {
	 int  Count_PlayerAWins = 0;
	 int  Count_PlayerBWins = 0;	 	 
	 long start, end;
	 long elapsedTime;
	 long timeMinutes;
	 int  totalGame =100;
	 
	 start = System.currentTimeMillis();
	 for(int i =0; i< totalGame ;i= i+1) {
		System.out.println(" ");
		System.out.println("<<<< NEW-GAME-START >>>> "+i);
		System.out.println(" ");
		int seedValue = 82356482;
				
		Player playerA = new RuleBasedPlayer("A");
		Player playerB = new RandomPlayer("B");
		/* Below Classes are used for Evaluating Rule-based player efficiency
		 * RuleBasedPlayer_WithOnlyRule1- this class contain only Rule 1.
		 * RuleBasedPlayer_WithOnlyRule2- this class contain only rule 2.
		*/
		//Player playerA = new RuleBasedPlayer_WithOnlyRule1("A");
		//Player playerA = new RuleBasedPlayer_WithOnlyRule2("A"); 
	    Game game = new Game(playerA, playerB, seedValue+i);
		Player winner = game.simulate();
		//Count_PlayerAWins += winner.equals(playerA) ? 1 : 0;
		//Count_PlayerBWins += winner.equals(playerB) ? 1 : 0;
		Count_PlayerAWins += winner == playerA ? 1 : 0;
		Count_PlayerBWins += winner == playerB ? 1 : 0;
		game.getHistory().printHistory();
		//System.out.println("Comparing " + winner + " and " + playerA + " : " + winner.equals(playerA));
	
	}
	end = System.currentTimeMillis();
	elapsedTime = end- start;
	timeMinutes = elapsedTime/60000;
	System.out.println(" "); 
	System.out.println("Percentage of Winning for Player A out of "+totalGame+" Moves is [" +((double) Count_PlayerAWins/totalGame)*100+"]");
	System.out.println("Player A wins " + Count_PlayerAWins + " times, Player B wins " + Count_PlayerBWins + " times.");
	System.out.println("Total time taken in millseconds "+elapsedTime);
	//System.out.println("Total time taken in minutes "+timeMinutes);	 
	
 }
	
	
	
}

