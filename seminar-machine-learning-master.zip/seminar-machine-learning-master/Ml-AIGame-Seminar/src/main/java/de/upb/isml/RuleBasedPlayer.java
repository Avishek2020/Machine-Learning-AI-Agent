package de.upb.isml;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import de.upb.isml.thegamef2f.engine.CardPosition;
import de.upb.isml.thegamef2f.engine.GameState;
import de.upb.isml.thegamef2f.engine.Move;
import de.upb.isml.thegamef2f.engine.Placement;
import de.upb.isml.thegamef2f.engine.board.Card;
import de.upb.isml.thegamef2f.engine.player.Player;


public class RuleBasedPlayer implements Player {

	private Random random;

	private String name;

	public RuleBasedPlayer(String name) {
		this.name = name;
	}

	@Override
	public void initialize(long randomSeed) {
		this.random = new Random(randomSeed);
	}

	@Override
	public Move computeMove(GameState gameState) {
		GameState currentGameState = gameState;
				
		//System.out.println("Player - HandCards - "+currentGameState.getHandCards()+"\n");		
		
		List<Placement> placementsOfMove = new ArrayList<Placement>();
		
		// Rule #1: help the other player, but help as little as possible:
		Card minHelpingCardAscending = null;
		int minHelpingCardAscendingNum = -1; // must be less than opponent's card, but as large as possible
		Card minHelpingCardDescending = null;
		int minHelpingCardDescendingNum = 61; // must be greater than opponent's card, but as small as possible
		int opponentAscending = gameState.getTopCardOnOpponentsAscendingDiscardPile().getNumber();
		int opponentDescending = gameState.getTopCardOnOpponentsDescendingDiscardPile().getNumber();
		for (Card card : currentGameState.getHandCards()) {
			// check opponent ascending pile:
			int cardNum = card.getNumber();
			//Opponent Ascending pile: Place a smaller card
			
			if (cardNum < opponentAscending // we must help the opponent
					//&& opponentAscending - cardNum != 10 // cannot place card w/ difference 10
					&& cardNum > minHelpingCardAscendingNum // we are looking for the least helping card
			) {
				minHelpingCardAscendingNum = cardNum;
				minHelpingCardAscending = card;
			}
			// check opponent descending pile:
			// Descending pile: Place a higher card
			if (cardNum > opponentDescending 
					//&& cardNum - opponentDescending !=10
					&& cardNum < minHelpingCardDescendingNum) {
				minHelpingCardDescendingNum =cardNum;
				minHelpingCardDescending = card;
			}
		}
		Placement p = null;
		if (opponentAscending - minHelpingCardAscendingNum < minHelpingCardDescendingNum - opponentDescending
				&& minHelpingCardAscending != null) {
			// we'd be helping less on the ascending pile
			p = new Placement(minHelpingCardAscending, CardPosition.OPPONENTS_ASCENDING_DISCARD_PILE);
		} else if (minHelpingCardDescending != null) {
			// we'd be helping less on the descending pile
			p = new Placement(minHelpingCardDescending, CardPosition.OPPONENTS_DESCENDING_DISCARD_PILE);
		}
		if (p != null) {
			placementsOfMove.add(p);
			currentGameState = computeNewGameStateAfterPlacement(currentGameState, p);
		}

		// as long as we still have hand cards
		while (!currentGameState.getHandCards().isEmpty()) {
			// Rule #2: place on own pile, hurt ourself as little as possible:
			Card minHurtingCardAscending = null;
			int minHurtingCardAscendingNum = 61; // must be greater than card on pile, but as small as possible
			Card minHurtingCardDescending = null;
			int minHurtingCardDescendingNum = -1; // must be less than card on pile, but as large as possible
			int ownAscending = gameState.getTopCardOnOwnAscendingDiscardPile().getNumber();
			int ownDescending = gameState.getTopCardOnOwnDescendingDiscardPile().getNumber();
			for (Card card : currentGameState.getHandCards()) {
				// check own ascending pile:
				int cardNum = card.getNumber();
				// Exceptions part ascending pile place card less than showing on pile exactly 10
				if ((cardNum > ownAscending || (ownAscending-cardNum ==10)) // we must hurt ourself
						//&& cardNum - ownAscending != 10 // cannot place card w/ difference 10
						&& cardNum < minHurtingCardAscendingNum) // we are looking for the least hurting card
				  {
					minHurtingCardAscendingNum = cardNum;
					minHurtingCardAscending = card;
				}
				// check own descending pile: 
				// Exceptions part descending pile place card larger than showing on pile exactly 10
				if ((cardNum < ownDescending || (cardNum - ownDescending ==10)) 
						//&& ownDescending-cardNum !=10
						&& cardNum > minHurtingCardDescendingNum) {
					minHurtingCardDescendingNum =cardNum;
					minHurtingCardDescending = card;
				}
			}
			
			p = null;
			if (minHurtingCardAscendingNum - ownAscending  < ownDescending - minHurtingCardDescendingNum
					&& minHurtingCardAscending != null) {
				// we'd be helping less on the ascending pile
				p = new Placement(minHurtingCardAscending, CardPosition.OWN_ASCENDING_DISCARD_PILE);
			} else if (minHurtingCardDescending != null) {
				// we'd be helping less on the descending pile
				p = new Placement(minHurtingCardDescending, CardPosition.OWN_DESCENDING_DISCARD_PILE);
			}
			
			if (p != null) {
				placementsOfMove.add(p);
				// update the view we have on the game to make sure that the next set of valid
				// placements is indeed valid
			//System.out.println("Hello--"+currentGameState.getHandCards());
				currentGameState = computeNewGameStateAfterPlacement(currentGameState, p);
			} else {
				break;
			}
		}

		return new Move(placementsOfMove);
	}

	private GameState computeNewGameStateAfterPlacement(GameState gameStatePriorToPlacement, Placement placement) {
		List<Card> handCards = new ArrayList<>(gameStatePriorToPlacement.getHandCards());
		handCards.remove(placement.getCard());

		List<Card> cardsOnOwnAscendingDiscardPile = new ArrayList<>(
				gameStatePriorToPlacement.getCardsOnOwnAscendingDiscardPile());
		if (placement.getPosition() == CardPosition.OWN_ASCENDING_DISCARD_PILE) {
			cardsOnOwnAscendingDiscardPile.add(placement.getCard());
		}

		List<Card> cardsOnOwnDescendingDiscardPile = new ArrayList<>(
				gameStatePriorToPlacement.getCardsOnOwnDescendingDiscardPile());
		if (placement.getPosition() == CardPosition.OWN_DESCENDING_DISCARD_PILE) {
			cardsOnOwnDescendingDiscardPile.add(placement.getCard());
		}

		List<Card> cardsOnOpponentsAscendingDiscardPile = new ArrayList<>(
				gameStatePriorToPlacement.getCardsOnOpponentsAscendingDiscardPile());
		if (placement.getPosition() == CardPosition.OPPONENTS_ASCENDING_DISCARD_PILE) {
			cardsOnOpponentsAscendingDiscardPile.add(placement.getCard());
		}

		List<Card> cardsOnOpponentsDescendingDiscardPile = new ArrayList<>(
				gameStatePriorToPlacement.getCardsOnOpponentsDescendingDiscardPile());
		if (placement.getPosition() == CardPosition.OPPONENTS_ASCENDING_DISCARD_PILE) {
			cardsOnOpponentsDescendingDiscardPile.add(placement.getCard());
		}

		return new GameState(handCards, cardsOnOwnAscendingDiscardPile, cardsOnOwnDescendingDiscardPile,
				cardsOnOpponentsAscendingDiscardPile, cardsOnOpponentsDescendingDiscardPile);
	}


	
	@Override
	public String toString() {
		return "rule_based_player_" + name;
	}

	@Override
	public String getName() {
		return toString();
	}


}
